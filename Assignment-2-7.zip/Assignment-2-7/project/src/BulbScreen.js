import {Component} from "react";

import LightOn from "./assets/images/light-on.png";
import LightOff from "./assets/images/light-off.png";

class BulbScreen extends Component {

    constructor(){
        super();
        this.state = {
            isLightOn:false
        }
        this.toggle = this.toggle.bind(this);
    }

    toggle(){
        const isLightOn = !this.state.isLightOn;
        this.setState({isLightOn:isLightOn});
    }

    render(){
        return <div>
            <img src={this.state.isLightOn ? LightOn : LightOff}></img>
            <button onClick={this.toggle}>Toggle</button>
        </div>
    }
}

export default BulbScreen;