import logo from './logo.svg';
import './App.css';
import BulbScreen from './BulbScreen';

function App() {
  return (
    <BulbScreen></BulbScreen>
  );
}

export default App;
